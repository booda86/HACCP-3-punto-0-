# HACCP Manager Pro — v1.0

Prima versione completa e strutturata dell'app.

## Moduli disponibili

- Login Firebase
- Ruoli Titolare / Chef / Dipendente
- Gestione personale
- Magazzino
- Prodotti e lotti
- Ricerca lotto
- Scadenze a 3 / 7 / 30 giorni
- Registro temperature
- Frigoriferi di esempio
- Scanner barcode / QR
- Report temperature PDF
- Report temperature Excel
- Notifiche locali sulle scadenze
- Database locale Drift / SQLite
- Cloud Functions per gestione sicura utenti

## Avvio

1. Genera le cartelle native:
   flutter create --platforms=android,ios .

2. Installa dipendenze:
   flutter pub get

3. Genera Drift:
   dart run build_runner build --delete-conflicting-outputs

4. Configura Firebase:
   flutterfire configure

5. Attiva Email/Password in Firebase Authentication.

6. Crea Firestore.

7. Installa e pubblica le Cloud Functions:
   cd functions
   npm install
   cd ..
   firebase deploy --only functions

8. Pubblica le regole:
   firebase deploy --only firestore:rules

9. Avvia:
   flutter run

## Permessi fotocamera

### Android

Aggiungi al Manifest:

    <uses-permission android:name="android.permission.CAMERA"/>

Per le notifiche Android 13+:

    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>

### iOS

Dentro `ios/Runner/Info.plist` aggiungi:

    <key>NSCameraUsageDescription</key>
    <string>La fotocamera serve per leggere barcode e QR dei lotti HACCP.</string>

    <key>NSPhotoLibraryUsageDescription</key>
    <string>La libreria foto può essere usata per allegare immagini ai prodotti.</string>

## Nota importante sulla produzione

La v1.0 è una base applicativa completa ma prima di pubblicarla su App Store
e Google Play vanno ancora completati:

- multi-ristorante / tenant isolation;
- backup e sincronizzazione completa dei dati locali su Firestore;
- policy privacy e termini;
- test automatici;
- gestione cancellazione account;
- audit log immutabile;
- esportazione completa HACCP;
- icone, splash, nome bundle e firma;
- validazione HACCP con il consulente/responsabile del piano aziendale.

Il software supporta la gestione operativa, ma non sostituisce il piano HACCP
specifico dell'attività né gli obblighi normativi applicabili.
