import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../database/database_providers.dart';
import '../../../services/notification_service.dart';
import '../../auth/domain/app_user.dart';
import '../../auth/providers/auth_providers.dart';

class DashboardPage extends ConsumerWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(currentUserProfileProvider);
    final user = profile.value;
    final expiries = ref.watch(scadenzeProvider(7));

    final items = <_DashboardItem>[
      _DashboardItem(
        title: 'Magazzino',
        subtitle: 'Prodotti, lotti e scadenze',
        icon: Icons.inventory_2_outlined,
        allowed: user?.ruolo.can(AppPermission.viewInventory) ?? false,
        onTap: () => context.go('/magazzino'),
      ),
      _DashboardItem(
        title: 'Ricerca lotto',
        subtitle: 'Ricerca e tracciabilità',
        icon: Icons.manage_search,
        allowed: user?.ruolo.can(AppPermission.viewInventory) ?? false,
        onTap: () => context.go('/ricerca-lotto'),
      ),
      _DashboardItem(
        title: 'Scadenze',
        subtitle: 'Controlla le prossime scadenze',
        icon: Icons.event_busy_outlined,
        allowed: user?.ruolo.can(AppPermission.viewInventory) ?? false,
        badge: expiries.value?.length,
        onTap: () => context.go('/scadenze'),
      ),
      _DashboardItem(
        title: 'Temperature',
        subtitle: 'Registro frigoriferi',
        icon: Icons.thermostat_outlined,
        allowed:
            user?.ruolo.can(AppPermission.recordTemperatures) ?? false,
        onTap: () => context.go('/temperature'),
      ),
      _DashboardItem(
        title: 'Scanner',
        subtitle: 'Barcode e QR code',
        icon: Icons.qr_code_scanner,
        allowed: user?.ruolo.can(AppPermission.scanLots) ?? false,
        onTap: () => context.go('/scanner'),
      ),
      _DashboardItem(
        title: 'Report HACCP',
        subtitle: 'PDF ed esportazioni',
        icon: Icons.picture_as_pdf_outlined,
        allowed: user?.ruolo.can(AppPermission.viewReports) ?? false,
        onTap: () => context.go('/report'),
      ),
      _DashboardItem(
        title: 'Personale',
        subtitle: 'Utenti, ruoli e accessi',
        icon: Icons.groups_2_outlined,
        allowed: user?.ruolo.can(AppPermission.manageStaff) ?? false,
        onTap: () => context.go('/personale'),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('HACCP Manager Pro'),
        actions: [
          IconButton(
            tooltip: 'Controlla scadenze',
            onPressed: () async {
              final count = expiries.value?.length ?? 0;
              await NotificationService.instance.showExpirySummary(count);
            },
            icon: const Icon(Icons.notifications_outlined),
          ),
          IconButton(
            tooltip: 'Esci',
            onPressed: () async {
              await ref.read(authRepositoryProvider).signOut();
              if (context.mounted) context.go('/login');
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          profile.when(
            loading: () => const LinearProgressIndicator(),
            error: (_, __) => const _ProfileWarning(),
            data: (user) {
              if (user == null) return const _ProfileWarning();
              return _WelcomeCard(user: user);
            },
          ),
          const SizedBox(height: 18),
          expiries.when(
            loading: () => const SizedBox.shrink(),
            error: (_, __) => const SizedBox.shrink(),
            data: (items) => Card(
              child: ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.event_busy_outlined),
                ),
                title: Text(
                  items.isEmpty
                      ? 'Nessuna scadenza critica'
                      : '${items.length} prodotti da controllare',
                ),
                subtitle: const Text('Scaduti o in scadenza entro 7 giorni'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.go('/scadenze'),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Dashboard',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 6),
          Text(
            'Le funzioni disponibili dipendono dal ruolo dell’utente.',
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          const SizedBox(height: 20),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: items.length,
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 320,
              mainAxisExtent: 172,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
            ),
            itemBuilder: (context, index) {
              final item = items[index];

              return Opacity(
                opacity: item.allowed ? 1 : 0.45,
                child: Card(
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: !item.allowed
                        ? () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Il tuo ruolo non ha il permesso per questa funzione.',
                                ),
                              ),
                            );
                          }
                        : item.onTap,
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                item.icon,
                                size: 36,
                                color:
                                    Theme.of(context).colorScheme.primary,
                              ),
                              const Spacer(),
                              if (item.badge != null && item.badge! > 0)
                                Badge(
                                  label: Text('${item.badge}'),
                                ),
                              if (!item.allowed)
                                const Padding(
                                  padding: EdgeInsets.only(left: 8),
                                  child: Icon(Icons.lock_outline, size: 20),
                                ),
                            ],
                          ),
                          const Spacer(),
                          Text(
                            item.title,
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge
                                ?.copyWith(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 4),
                          Text(item.subtitle),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  const _WelcomeCard({required this.user});

  final AppUser user;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              radius: 28,
              child: Icon(Icons.person_outline),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Ciao ${user.nome}',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(user.email),
                ],
              ),
            ),
            Chip(label: Text(user.ruolo.label)),
          ],
        ),
      ),
    );
  }
}

class _ProfileWarning extends StatelessWidget {
  const _ProfileWarning();

  @override
  Widget build(BuildContext context) {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Text(
          'Accesso Firebase riuscito, ma il profilo Firestore non è disponibile.',
        ),
      ),
    );
  }
}

class _DashboardItem {
  const _DashboardItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.allowed,
    required this.onTap,
    this.badge,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final bool allowed;
  final VoidCallback onTap;
  final int? badge;
}
