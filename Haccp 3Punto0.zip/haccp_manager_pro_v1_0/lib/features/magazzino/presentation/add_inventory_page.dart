import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../database/database_providers.dart';

class AddInventoryPage extends ConsumerStatefulWidget {
  const AddInventoryPage({super.key});

  @override
  ConsumerState<AddInventoryPage> createState() =>
      _AddInventoryPageState();
}

class _AddInventoryPageState extends ConsumerState<AddInventoryPage> {
  final formKey = GlobalKey<FormState>();

  final nomeController = TextEditingController();
  final marcaController = TextEditingController();
  final fornitoreController = TextEditingController();
  final allergeniController = TextEditingController();
  final barcodeController = TextEditingController();
  final qrCodeController = TextEditingController();
  final lottoController = TextEditingController();
  final quantitaController = TextEditingController();
  final posizioneController = TextEditingController();
  final noteController = TextEditingController();

  String categoria = 'Pesce';
  String unitaMisura = 'kg';
  DateTime dataArrivo = DateTime.now();
  DateTime? dataScadenza;
  bool saving = false;

  final categorie = const [
    'Pesce',
    'Carne',
    'Latticini',
    'Ortofrutta',
    'Surgelati',
    'Dispensa',
    'Bevande',
    'Altro',
  ];

  @override
  void dispose() {
    nomeController.dispose();
    marcaController.dispose();
    fornitoreController.dispose();
    allergeniController.dispose();
    barcodeController.dispose();
    qrCodeController.dispose();
    lottoController.dispose();
    quantitaController.dispose();
    posizioneController.dispose();
    noteController.dispose();
    super.dispose();
  }

  Future<DateTime?> _pickDate(
    BuildContext context, {
    required DateTime initialDate,
  }) {
    return showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
  }

  Future<void> _save() async {
    if (!(formKey.currentState?.validate() ?? false)) return;

    setState(() => saving = true);

    try {
      final rawQty = quantitaController.text
          .trim()
          .replaceAll(',', '.');

      final quantita =
          rawQty.isEmpty ? null : double.tryParse(rawQty);

      await ref.read(databaseProvider).creaProdottoConLotto(
            nomeProdotto: nomeController.text,
            categoria: categoria,
            marca: marcaController.text,
            fornitore: fornitoreController.text,
            allergeni: allergeniController.text,
            barcode: barcodeController.text,
            qrCode: qrCodeController.text,
            numeroLotto: lottoController.text,
            dataArrivo: dataArrivo,
            dataScadenza: dataScadenza,
            quantita: quantita,
            unitaMisura: unitaMisura,
            posizione: posizioneController.text,
            noteLotto: noteController.text,
          );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Prodotto e lotto salvati correttamente.'),
        ),
      );

      context.pop();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Errore durante il salvataggio: $e'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => saving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateFormat = DateFormat('dd/MM/yyyy');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Nuovo arrivo'),
      ),
      body: SafeArea(
        child: Form(
          key: formKey,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                'Prodotto',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: nomeController,
                decoration: const InputDecoration(
                  labelText: 'Nome prodotto *',
                  hintText: 'Es. Salmone fresco',
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Inserisci il nome del prodotto';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: categoria,
                decoration: const InputDecoration(
                  labelText: 'Categoria *',
                ),
                items: categorie
                    .map(
                      (value) => DropdownMenuItem(
                        value: value,
                        child: Text(value),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() => categoria = value);
                  }
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: marcaController,
                decoration: const InputDecoration(
                  labelText: 'Marca',
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: fornitoreController,
                decoration: const InputDecoration(
                  labelText: 'Fornitore',
                  hintText: 'Es. Metro',
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: barcodeController,
                decoration: const InputDecoration(
                  labelText: 'Barcode',
                  hintText: 'Codice EAN/UPC se presente',
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: qrCodeController,
                decoration: const InputDecoration(
                  labelText: 'QR interno',
                  hintText: 'Codice interno opzionale',
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: allergeniController,
                decoration: const InputDecoration(
                  labelText: 'Allergeni',
                  hintText: 'Es. pesce, latte, glutine...',
                ),
              ),
              const SizedBox(height: 28),
              Text(
                'Lotto e tracciabilità',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: lottoController,
                decoration: const InputDecoration(
                  labelText: 'Numero lotto *',
                  hintText: 'Es. SAL260825',
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Inserisci il numero del lotto';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 12),
              _DateTile(
                label: 'Data arrivo',
                value: dateFormat.format(dataArrivo),
                icon: Icons.local_shipping_outlined,
                onTap: () async {
                  final selected = await _pickDate(
                    context,
                    initialDate: dataArrivo,
                  );

                  if (selected != null) {
                    setState(() => dataArrivo = selected);
                  }
                },
              ),
              const SizedBox(height: 12),
              _DateTile(
                label: 'Data scadenza',
                value: dataScadenza == null
                    ? 'Non impostata'
                    : dateFormat.format(dataScadenza!),
                icon: Icons.event_outlined,
                onTap: () async {
                  final selected = await _pickDate(
                    context,
                    initialDate:
                        dataScadenza ?? dataArrivo.add(const Duration(days: 7)),
                  );

                  if (selected != null) {
                    setState(() => dataScadenza = selected);
                  }
                },
              ),
              const SizedBox(height: 12),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 2,
                    child: TextFormField(
                      controller: quantitaController,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: const InputDecoration(
                        labelText: 'Quantità',
                        hintText: '12',
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      initialValue: unitaMisura,
                      decoration: const InputDecoration(
                        labelText: 'Unità',
                      ),
                      items: const [
                        DropdownMenuItem(value: 'kg', child: Text('kg')),
                        DropdownMenuItem(value: 'g', child: Text('g')),
                        DropdownMenuItem(value: 'pz', child: Text('pz')),
                        DropdownMenuItem(value: 'L', child: Text('L')),
                        DropdownMenuItem(value: 'ml', child: Text('ml')),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setState(() => unitaMisura = value);
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: posizioneController,
                decoration: const InputDecoration(
                  labelText: 'Posizione',
                  hintText: 'Es. Frigo pesce 1',
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: noteController,
                minLines: 2,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Note',
                ),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: saving ? null : _save,
                icon: saving
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                        ),
                      )
                    : const Icon(Icons.save_outlined),
                label: Text(saving ? 'Salvataggio...' : 'Salva in magazzino'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DateTile extends StatelessWidget {
  const _DateTile({
    required this.label,
    required this.value,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final String value;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).colorScheme.surfaceContainerLow,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Icon(icon),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: Theme.of(context).textTheme.labelMedium,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      value,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}
