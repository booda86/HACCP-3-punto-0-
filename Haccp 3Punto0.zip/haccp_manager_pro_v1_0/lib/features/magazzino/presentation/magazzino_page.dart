import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../database/app_database.dart';
import '../../../database/database_providers.dart';
import '../../auth/domain/app_user.dart';
import '../../auth/providers/auth_providers.dart';

class MagazzinoPage extends ConsumerWidget {
  const MagazzinoPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final magazzino = ref.watch(magazzinoProvider);
    final role = ref.watch(currentRoleProvider);

    final canEdit = role?.can(AppPermission.editInventory) ?? false;
    final canDelete = role?.can(AppPermission.deleteLots) ?? false;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Magazzino'),
        leading: IconButton(
          onPressed: () => context.go('/dashboard'),
          icon: const Icon(Icons.arrow_back),
        ),
      ),
      floatingActionButton: canEdit
          ? FloatingActionButton.extended(
              onPressed: () => context.push('/magazzino/nuovo'),
              icon: const Icon(Icons.add),
              label: const Text('Nuovo arrivo'),
            )
          : null,
      body: magazzino.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stackTrace) => _ErrorView(error: error),
        data: (items) {
          if (items.isEmpty) {
            return _EmptyView(canEdit: canEdit);
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              return _LottoCard(
                item: items[index],
                canDelete: canDelete,
              );
            },
          );
        },
      ),
    );
  }
}

class _LottoCard extends ConsumerWidget {
  const _LottoCard({
    required this.item,
    required this.canDelete,
  });

  final LottoConProdotto item;
  final bool canDelete;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dateFormat = DateFormat('dd/MM/yyyy');
    final scadenza = item.lotto.dataScadenza;
    final now = DateTime.now();

    final giorniAllaScadenza = scadenza == null
        ? null
        : DateTime(scadenza.year, scadenza.month, scadenza.day)
            .difference(DateTime(now.year, now.month, now.day))
            .inDays;

    final isExpired =
        giorniAllaScadenza != null && giorniAllaScadenza < 0;
    final isClose = giorniAllaScadenza != null &&
        giorniAllaScadenza >= 0 &&
        giorniAllaScadenza <= 3;

    final statusText = scadenza == null
        ? 'Scadenza non inserita'
        : isExpired
            ? 'SCADUTO'
            : isClose
                ? 'Scade tra $giorniAllaScadenza gg'
                : 'Scade ${dateFormat.format(scadenza)}';

    final statusColor = isExpired
        ? Theme.of(context).colorScheme.error
        : isClose
            ? Theme.of(context).colorScheme.tertiary
            : Theme.of(context).colorScheme.primary;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              child: Icon(_categoryIcon(item.prodotto.categoria)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.prodotto.nome,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    '${item.prodotto.categoria} • Lotto ${item.lotto.numeroLotto}',
                  ),
                  if (item.lotto.quantita != null) ...[
                    const SizedBox(height: 4),
                    Text('${item.lotto.quantita} ${item.lotto.unitaMisura}'),
                  ],
                  if (item.lotto.posizione != null) ...[
                    const SizedBox(height: 4),
                    Text('Posizione: ${item.lotto.posizione}'),
                  ],
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(
                      statusText,
                      style: TextStyle(
                        color: statusColor,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (canDelete)
              PopupMenuButton<String>(
                onSelected: (value) async {
                  if (value != 'delete') return;

                  await ref
                      .read(databaseProvider)
                      .eliminaLotto(item.lotto.id);

                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Lotto eliminato dal magazzino.'),
                      ),
                    );
                  }
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'delete',
                    child: Text('Elimina lotto'),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  IconData _categoryIcon(String categoria) {
    switch (categoria.toLowerCase()) {
      case 'pesce':
        return Icons.set_meal_outlined;
      case 'carne':
        return Icons.restaurant_outlined;
      case 'latticini':
        return Icons.breakfast_dining_outlined;
      case 'verdura':
      case 'ortofrutta':
        return Icons.eco_outlined;
      case 'surgelati':
        return Icons.ac_unit;
      default:
        return Icons.inventory_2_outlined;
    }
  }
}

class _EmptyView extends StatelessWidget {
  const _EmptyView({required this.canEdit});

  final bool canEdit;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.inventory_2_outlined, size: 72),
            const SizedBox(height: 16),
            Text(
              'Magazzino vuoto',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              canEdit
                  ? 'Premi “Nuovo arrivo” per registrare il primo prodotto.'
                  : 'Non ci sono ancora prodotti registrati.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.error});

  final Object error;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          'Errore database:\n$error',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
