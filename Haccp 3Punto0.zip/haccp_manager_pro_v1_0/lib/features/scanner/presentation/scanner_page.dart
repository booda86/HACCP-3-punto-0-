import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../../database/database_providers.dart';

class ScannerPage extends ConsumerStatefulWidget {
  const ScannerPage({super.key});

  @override
  ConsumerState<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends ConsumerState<ScannerPage> {
  final controller = MobileScannerController();
  bool handled = false;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> _handle(String value) async {
    if (handled) return;
    handled = true;
    await controller.stop();

    final results = await ref.read(databaseProvider).searchLotti(value);

    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Codice rilevato'),
        content: results.isEmpty
            ? Text(
                '$value\n\nNessun lotto associato. Puoi usare questo codice '
                'quando inserisci un nuovo prodotto.',
              )
            : Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(value),
                  const SizedBox(height: 16),
                  ...results.take(5).map(
                        (item) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(item.prodotto.nome),
                          subtitle:
                              Text('Lotto ${item.lotto.numeroLotto}'),
                        ),
                      ),
                ],
              ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Chiudi'),
          ),
        ],
      ),
    );

    if (!mounted) return;
    handled = false;
    await controller.start();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scanner lotto'),
        actions: [
          IconButton(
            onPressed: controller.toggleTorch,
            icon: const Icon(Icons.flashlight_on_outlined),
          ),
          IconButton(
            onPressed: controller.switchCamera,
            icon: const Icon(Icons.cameraswitch_outlined),
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          MobileScanner(
            controller: controller,
            onDetect: (capture) {
              final code = capture.barcodes
                  .map((b) => b.rawValue)
                  .whereType<String>()
                  .firstOrNull;

              if (code != null) {
                _handle(code);
              }
            },
          ),
          Center(
            child: Container(
              width: 260,
              height: 180,
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.white,
                  width: 3,
                ),
                borderRadius: BorderRadius.circular(18),
              ),
            ),
          ),
          const Positioned(
            left: 24,
            right: 24,
            bottom: 40,
            child: Card(
              child: Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                  'Inquadra un barcode o un QR code. '
                  'Se il codice è già associato a un lotto, '
                  'l’app mostrerà subito la tracciabilità.',
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
