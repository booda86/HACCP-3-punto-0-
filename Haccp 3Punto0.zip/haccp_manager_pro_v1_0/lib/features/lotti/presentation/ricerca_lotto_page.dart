import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../database/app_database.dart';
import '../../../database/database_providers.dart';

class RicercaLottoPage extends ConsumerStatefulWidget {
  const RicercaLottoPage({super.key});

  @override
  ConsumerState<RicercaLottoPage> createState() => _RicercaLottoPageState();
}

class _RicercaLottoPageState extends ConsumerState<RicercaLottoPage> {
  final controller = TextEditingController();
  List<LottoConProdotto> results = const [];
  bool loading = false;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    setState(() => loading = true);

    final data =
        await ref.read(databaseProvider).searchLotti(controller.text);

    if (!mounted) return;
    setState(() {
      results = data;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ricerca lotto')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: SearchBar(
              controller: controller,
              hintText: 'Nome, lotto, barcode o QR',
              leading: const Icon(Icons.search),
              trailing: [
                IconButton(
                  tooltip: 'Cerca',
                  onPressed: _search,
                  icon: const Icon(Icons.arrow_forward),
                ),
              ],
              onSubmitted: (_) => _search(),
            ),
          ),
          if (loading) const LinearProgressIndicator(),
          Expanded(
            child: results.isEmpty
                ? const Center(
                    child: Text(
                      'Inserisci un termine e premi Cerca.',
                      textAlign: TextAlign.center,
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: results.length,
                    separatorBuilder: (_, __) =>
                        const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      return _ResultCard(item: results[index]);
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  const _ResultCard({required this.item});

  final LottoConProdotto item;

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('dd/MM/yyyy');

    return Card(
      child: ListTile(
        leading: const CircleAvatar(
          child: Icon(Icons.inventory_2_outlined),
        ),
        title: Text(item.prodotto.nome),
        subtitle: Text(
          'Lotto: ${item.lotto.numeroLotto}\n'
          'Scadenza: ${item.lotto.dataScadenza == null ? '-' : df.format(item.lotto.dataScadenza!)}'
          '${item.lotto.posizione == null ? '' : '\nPosizione: ${item.lotto.posizione}'}',
        ),
        isThreeLine: true,
      ),
    );
  }
}
