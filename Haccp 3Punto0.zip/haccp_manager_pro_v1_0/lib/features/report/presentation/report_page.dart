import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../../../services/service_providers.dart';

class ReportPage extends ConsumerStatefulWidget {
  const ReportPage({super.key});

  @override
  ConsumerState<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends ConsumerState<ReportPage> {
  bool loading = false;

  DateTime get from {
    final now = DateTime.now();
    return DateTime(now.year, now.month, 1);
  }

  DateTime get to => DateTime.now();

  Future<void> _pdf() async {
    setState(() => loading = true);

    try {
      final file = await ref
          .read(reportServiceProvider)
          .generaReportTemperaturePdf(from: from, to: to);

      final bytes = await file.readAsBytes();

      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'Report temperature HACCP',
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _excel() async {
    setState(() => loading = true);

    try {
      final file = await ref
          .read(reportServiceProvider)
          .generaReportTemperatureExcel(from: from, to: to);

      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path)],
          text: 'Report temperature HACCP',
        ),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Report HACCP')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'I report vengono generati dai dati registrati '
                'nell’app. Questa versione include il registro '
                'temperature mensile in PDF ed Excel.',
              ),
            ),
          ),
          const SizedBox(height: 16),
          ListTile(
            leading: const CircleAvatar(
              child: Icon(Icons.picture_as_pdf_outlined),
            ),
            title: const Text('Registro temperature PDF'),
            subtitle: const Text('Mese corrente'),
            trailing: const Icon(Icons.chevron_right),
            onTap: loading ? null : _pdf,
          ),
          const Divider(),
          ListTile(
            leading: const CircleAvatar(
              child: Icon(Icons.table_chart_outlined),
            ),
            title: const Text('Registro temperature Excel'),
            subtitle: const Text('Mese corrente'),
            trailing: const Icon(Icons.chevron_right),
            onTap: loading ? null : _excel,
          ),
          if (loading) ...[
            const SizedBox(height: 20),
            const LinearProgressIndicator(),
          ],
        ],
      ),
    );
  }
}
