import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/auth_repository.dart';
import '../domain/app_user.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository();
});

final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(authRepositoryProvider).authStateChanges();
});

final currentUserProfileProvider = StreamProvider<AppUser?>((ref) {
  final auth = ref.watch(authStateProvider);

  return auth.when(
    data: (firebaseUser) {
      if (firebaseUser == null) {
        return Stream.value(null);
      }

      return ref
          .watch(authRepositoryProvider)
          .watchProfile(firebaseUser.uid);
    },
    loading: () => Stream.value(null),
    error: (_, __) => Stream.value(null),
  );
});

final currentRoleProvider = Provider<UserRole?>((ref) {
  return ref.watch(currentUserProfileProvider).value?.ruolo;
});

final canManageStaffProvider = Provider<bool>((ref) {
  final role = ref.watch(currentRoleProvider);
  return role?.can(AppPermission.manageStaff) ?? false;
});
