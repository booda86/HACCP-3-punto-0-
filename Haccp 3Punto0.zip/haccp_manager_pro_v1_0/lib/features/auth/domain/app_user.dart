enum UserRole {
  titolare,
  chef,
  dipendente;

  String get label {
    switch (this) {
      case UserRole.titolare:
        return 'Titolare';
      case UserRole.chef:
        return 'Chef';
      case UserRole.dipendente:
        return 'Dipendente';
    }
  }

  String get firestoreValue => name;

  static UserRole fromString(String? value) {
    switch (value) {
      case 'titolare':
        return UserRole.titolare;
      case 'chef':
        return UserRole.chef;
      case 'dipendente':
      default:
        return UserRole.dipendente;
    }
  }
}

enum AppPermission {
  viewInventory,
  editInventory,
  deleteLots,
  recordTemperatures,
  viewReports,
  createReports,
  scanLots,
  manageStaff,
}

extension UserRolePermissions on UserRole {
  Set<AppPermission> get permissions {
    switch (this) {
      case UserRole.titolare:
        return AppPermission.values.toSet();

      case UserRole.chef:
        return {
          AppPermission.viewInventory,
          AppPermission.editInventory,
          AppPermission.deleteLots,
          AppPermission.recordTemperatures,
          AppPermission.viewReports,
          AppPermission.createReports,
          AppPermission.scanLots,
        };

      case UserRole.dipendente:
        return {
          AppPermission.viewInventory,
          AppPermission.recordTemperatures,
          AppPermission.scanLots,
        };
    }
  }

  bool can(AppPermission permission) => permissions.contains(permission);
}

class AppUser {
  const AppUser({
    required this.uid,
    required this.nome,
    required this.email,
    required this.ruolo,
    required this.attivo,
  });

  final String uid;
  final String nome;
  final String email;
  final UserRole ruolo;
  final bool attivo;

  factory AppUser.fromMap(String uid, Map<String, dynamic> data) {
    return AppUser(
      uid: uid,
      nome: (data['nome'] as String?)?.trim().isNotEmpty == true
          ? data['nome'] as String
          : 'Utente',
      email: data['email'] as String? ?? '',
      ruolo: UserRole.fromString(data['ruolo'] as String?),
      attivo: data['attivo'] as bool? ?? true,
    );
  }
}
