import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../domain/app_user.dart';

class AuthRepository {
  AuthRepository({
    FirebaseAuth? auth,
    FirebaseFirestore? firestore,
  })  : _auth = auth ?? FirebaseAuth.instance,
        _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  User? get currentFirebaseUser => _auth.currentUser;

  Future<AppUser?> loadProfile(String uid) async {
    final doc = await _firestore.collection('utenti').doc(uid).get();

    if (!doc.exists || doc.data() == null) {
      return null;
    }

    return AppUser.fromMap(doc.id, doc.data()!);
  }

  Stream<AppUser?> watchProfile(String uid) {
    return _firestore.collection('utenti').doc(uid).snapshots().map((doc) {
      final data = doc.data();
      if (!doc.exists || data == null) return null;
      return AppUser.fromMap(doc.id, data);
    });
  }

  Future<UserCredential> signIn({
    required String email,
    required String password,
  }) async {
    final credential = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );

    final user = credential.user;
    if (user == null) {
      throw FirebaseAuthException(
        code: 'user-not-found',
        message: 'Utente non disponibile.',
      );
    }

    final profile = await loadProfile(user.uid);

    if (profile != null && !profile.attivo) {
      await _auth.signOut();
      throw FirebaseAuthException(
        code: 'user-disabled',
        message: 'Questo account è stato disattivato dal titolare.',
      );
    }

    return credential;
  }

  Future<UserCredential> registerOwner({
    required String nome,
    required String email,
    required String password,
  }) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );

    final user = credential.user;

    if (user == null) {
      throw StateError('Creazione utente non completata.');
    }

    await user.updateDisplayName(nome.trim());

    await _firestore.collection('utenti').doc(user.uid).set({
      'nome': nome.trim(),
      'email': email.trim().toLowerCase(),
      'ruolo': 'titolare',
      'attivo': true,
      'createdAt': FieldValue.serverTimestamp(),
    });

    return credential;
  }

  Future<void> sendPasswordReset(String email) {
    return _auth.sendPasswordResetEmail(email: email.trim());
  }

  Future<void> signOut() => _auth.signOut();
}
