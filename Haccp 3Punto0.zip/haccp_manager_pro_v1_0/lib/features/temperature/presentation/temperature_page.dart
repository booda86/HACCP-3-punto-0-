import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../database/app_database.dart';
import '../../../database/database_providers.dart';
import '../../auth/providers/auth_providers.dart';

class TemperaturePage extends ConsumerWidget {
  const TemperaturePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final data = ref.watch(temperatureProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Registro temperature')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showDialog<void>(
          context: context,
          builder: (_) => const _AddTemperatureDialog(),
        ),
        icon: const Icon(Icons.add),
        label: const Text('Registra'),
      ),
      body: data.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Errore: $e')),
        data: (items) {
          if (items.isEmpty) {
            return const Center(
              child: Text('Nessuna temperatura registrata.'),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final item = items[index];
              final out = item.temperatura.esito == 'fuori_limite';

              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    child: Icon(
                      out
                          ? Icons.warning_amber_rounded
                          : Icons.thermostat_outlined,
                    ),
                  ),
                  title: Text(item.frigo.nome),
                  subtitle: Text(
                    '${DateFormat('dd/MM/yyyy HH:mm').format(item.temperatura.rilevataAt)}'
                    '${item.temperatura.operatore == null ? '' : '\n${item.temperatura.operatore}'}',
                  ),
                  trailing: Text(
                    '${item.temperatura.valore.toStringAsFixed(1)} °C',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: out
                          ? Theme.of(context).colorScheme.error
                          : null,
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _AddTemperatureDialog extends ConsumerStatefulWidget {
  const _AddTemperatureDialog();

  @override
  ConsumerState<_AddTemperatureDialog> createState() =>
      _AddTemperatureDialogState();
}

class _AddTemperatureDialogState
    extends ConsumerState<_AddTemperatureDialog> {
  final valueController = TextEditingController();
  final noteController = TextEditingController();
  final correctiveController = TextEditingController();

  int? selectedFrigo;
  bool saving = false;

  @override
  void dispose() {
    valueController.dispose();
    noteController.dispose();
    correctiveController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final value =
        double.tryParse(valueController.text.trim().replaceAll(',', '.'));

    if (selectedFrigo == null || value == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seleziona un frigo e una temperatura.')),
      );
      return;
    }

    setState(() => saving = true);

    final operatorName =
        ref.read(currentUserProfileProvider).value?.nome ?? 'Operatore';

    await ref.read(databaseProvider).registraTemperatura(
          frigoriferoId: selectedFrigo!,
          valore: value,
          operatore: operatorName,
          note: noteController.text,
          azioneCorrettiva: correctiveController.text,
        );

    if (!mounted) return;
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final fridges = ref.watch(frigoriferiProvider);

    return AlertDialog(
      title: const Text('Registra temperatura'),
      content: SizedBox(
        width: 440,
        child: fridges.when(
          loading: () => const CircularProgressIndicator(),
          error: (e, _) => Text('Errore: $e'),
          data: (items) => SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<int>(
                  initialValue: selectedFrigo,
                  decoration: const InputDecoration(
                    labelText: 'Frigorifero',
                  ),
                  items: items
                      .map(
                        (f) => DropdownMenuItem(
                          value: f.id,
                          child: Text(f.nome),
                        ),
                      )
                      .toList(),
                  onChanged: (value) =>
                      setState(() => selectedFrigo = value),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: valueController,
                  keyboardType: const TextInputType.numberWithOptions(
                    signed: true,
                    decimal: true,
                  ),
                  decoration: const InputDecoration(
                    labelText: 'Temperatura °C',
                    hintText: 'Es. 3,2',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: noteController,
                  decoration: const InputDecoration(labelText: 'Note'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: correctiveController,
                  minLines: 2,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Azione correttiva (se necessaria)',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: saving ? null : () => Navigator.pop(context),
          child: const Text('Annulla'),
        ),
        FilledButton(
          onPressed: saving ? null : _save,
          child: Text(saving ? 'Salvataggio...' : 'Salva'),
        ),
      ],
    );
  }
}
