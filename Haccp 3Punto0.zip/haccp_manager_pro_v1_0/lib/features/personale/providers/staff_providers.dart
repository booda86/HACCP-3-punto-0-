import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../auth/domain/app_user.dart';
import '../data/staff_repository.dart';

final staffRepositoryProvider = Provider<StaffRepository>((ref) {
  return StaffRepository();
});

final staffListProvider = StreamProvider<List<AppUser>>((ref) {
  return ref.watch(staffRepositoryProvider).watchStaff();
});
