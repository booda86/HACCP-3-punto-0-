import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';

import '../../auth/domain/app_user.dart';

class StaffRepository {
  StaffRepository({
    FirebaseFirestore? firestore,
    FirebaseFunctions? functions,
  })  : _firestore = firestore ?? FirebaseFirestore.instance,
        _functions = functions ?? FirebaseFunctions.instance;

  final FirebaseFirestore _firestore;
  final FirebaseFunctions _functions;

  Stream<List<AppUser>> watchStaff() {
    return _firestore
        .collection('utenti')
        .orderBy('nome')
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => AppUser.fromMap(doc.id, doc.data()))
          .toList();
    });
  }

  Future<void> createStaffUser({
    required String nome,
    required String email,
    required String password,
    required UserRole ruolo,
  }) async {
    if (ruolo == UserRole.titolare) {
      throw ArgumentError('Il nuovo utente deve essere Chef o Dipendente.');
    }

    final callable = _functions.httpsCallable('createStaffUser');

    await callable.call({
      'nome': nome.trim(),
      'email': email.trim().toLowerCase(),
      'password': password,
      'ruolo': ruolo.firestoreValue,
    });
  }

  Future<void> setStaffRole({
    required String uid,
    required UserRole ruolo,
  }) async {
    final callable = _functions.httpsCallable('setStaffRole');

    await callable.call({
      'uid': uid,
      'ruolo': ruolo.firestoreValue,
    });
  }

  Future<void> setStaffActive({
    required String uid,
    required bool attivo,
  }) async {
    final callable = _functions.httpsCallable('setStaffActive');

    await callable.call({
      'uid': uid,
      'attivo': attivo,
    });
  }
}
