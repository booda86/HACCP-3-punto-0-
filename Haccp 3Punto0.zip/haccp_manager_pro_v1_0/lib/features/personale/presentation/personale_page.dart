import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../auth/domain/app_user.dart';
import '../../auth/providers/auth_providers.dart';
import '../providers/staff_providers.dart';

class PersonalePage extends ConsumerWidget {
  const PersonalePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final canManage = ref.watch(canManageStaffProvider);
    final currentUser = ref.watch(currentUserProfileProvider).value;
    final staff = ref.watch(staffListProvider);

    if (!canManage) {
      return Scaffold(
        appBar: AppBar(title: const Text('Personale')),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(24),
            child: Text(
              'Solo il Titolare può gestire gli utenti e i loro permessi.',
              textAlign: TextAlign.center,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Gestione personale')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showDialog<void>(
          context: context,
          builder: (_) => const _CreateStaffDialog(),
        ),
        icon: const Icon(Icons.person_add_alt_1),
        label: const Text('Nuovo utente'),
      ),
      body: staff.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, _) => Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Errore: $error'),
          ),
        ),
        data: (users) {
          if (users.isEmpty) {
            return const Center(child: Text('Nessun utente registrato.'));
          }

          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
            itemCount: users.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final user = users[index];
              final isMe = user.uid == currentUser?.uid;

              return _StaffCard(
                user: user,
                isCurrentUser: isMe,
              );
            },
          );
        },
      ),
    );
  }
}

class _StaffCard extends ConsumerWidget {
  const _StaffCard({
    required this.user,
    required this.isCurrentUser,
  });

  final AppUser user;
  final bool isCurrentUser;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  child: Text(
                    user.nome.trim().isEmpty
                        ? '?'
                        : user.nome.trim()[0].toUpperCase(),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              user.nome,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(fontWeight: FontWeight.bold),
                            ),
                          ),
                          if (isCurrentUser) ...[
                            const SizedBox(width: 6),
                            const Chip(label: Text('Tu')),
                          ],
                        ],
                      ),
                      Text(user.email),
                    ],
                  ),
                ),
                Icon(
                  user.attivo
                      ? Icons.check_circle_outline
                      : Icons.block_outlined,
                  color: user.attivo
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.error,
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<UserRole>(
                    initialValue: user.ruolo,
                    decoration: const InputDecoration(labelText: 'Ruolo'),
                    items: UserRole.values.map((role) {
                      return DropdownMenuItem(
                        value: role,
                        child: Text(role.label),
                      );
                    }).toList(),
                    onChanged: isCurrentUser
                        ? null
                        : (role) async {
                            if (role == null) return;

                            try {
                              await ref
                                  .read(staffRepositoryProvider)
                                  .setStaffRole(
                                    uid: user.uid,
                                    ruolo: role,
                                  );
                            } on FirebaseFunctionsException catch (e) {
                              if (!context.mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    e.message ?? 'Modifica ruolo non riuscita.',
                                  ),
                                ),
                              );
                            }
                          },
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  children: [
                    const Text('Attivo'),
                    Switch(
                      value: user.attivo,
                      onChanged: isCurrentUser
                          ? null
                          : (value) async {
                              try {
                                await ref
                                    .read(staffRepositoryProvider)
                                    .setStaffActive(
                                      uid: user.uid,
                                      attivo: value,
                                    );
                              } on FirebaseFunctionsException catch (e) {
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      e.message ??
                                          'Modifica stato non riuscita.',
                                    ),
                                  ),
                                );
                              }
                            },
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            _PermissionSummary(role: user.ruolo),
          ],
        ),
      ),
    );
  }
}

class _PermissionSummary extends StatelessWidget {
  const _PermissionSummary({required this.role});

  final UserRole role;

  @override
  Widget build(BuildContext context) {
    final permissions = <String>[
      if (role.can(AppPermission.viewInventory)) 'Magazzino',
      if (role.can(AppPermission.editInventory)) 'Modifica lotti',
      if (role.can(AppPermission.recordTemperatures)) 'Temperature',
      if (role.can(AppPermission.createReports)) 'Report',
      if (role.can(AppPermission.scanLots)) 'Scanner',
      if (role.can(AppPermission.manageStaff)) 'Personale',
    ];

    return Align(
      alignment: Alignment.centerLeft,
      child: Wrap(
        spacing: 6,
        runSpacing: 6,
        children: permissions
            .map((permission) => Chip(label: Text(permission)))
            .toList(),
      ),
    );
  }
}

class _CreateStaffDialog extends ConsumerStatefulWidget {
  const _CreateStaffDialog();

  @override
  ConsumerState<_CreateStaffDialog> createState() =>
      _CreateStaffDialogState();
}

class _CreateStaffDialogState extends ConsumerState<_CreateStaffDialog> {
  final formKey = GlobalKey<FormState>();
  final nomeController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  UserRole ruolo = UserRole.dipendente;
  bool loading = false;

  @override
  void dispose() {
    nomeController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    if (!(formKey.currentState?.validate() ?? false)) return;

    setState(() => loading = true);

    try {
      await ref.read(staffRepositoryProvider).createStaffUser(
            nome: nomeController.text,
            email: emailController.text,
            password: passwordController.text,
            ruolo: ruolo,
          );

      if (!mounted) return;
      Navigator.of(context).pop();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Utente creato correttamente.')),
      );
    } on FirebaseFunctionsException catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.message ?? 'Creazione utente non riuscita.'),
        ),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Nuovo utente'),
      content: SizedBox(
        width: 440,
        child: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: nomeController,
                  decoration: const InputDecoration(
                    labelText: 'Nome e cognome',
                  ),
                  validator: (value) => (value?.trim().isEmpty ?? true)
                      ? 'Inserisci il nome'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: emailController,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email'),
                  validator: (value) => !(value?.contains('@') ?? false)
                      ? 'Email non valida'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Password provvisoria',
                  ),
                  validator: (value) => (value ?? '').length < 8
                      ? 'Usa almeno 8 caratteri'
                      : null,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<UserRole>(
                  initialValue: ruolo,
                  decoration: const InputDecoration(labelText: 'Ruolo'),
                  items: const [
                    DropdownMenuItem(
                      value: UserRole.chef,
                      child: Text('Chef'),
                    ),
                    DropdownMenuItem(
                      value: UserRole.dipendente,
                      child: Text('Dipendente'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) setState(() => ruolo = value);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: loading ? null : () => Navigator.pop(context),
          child: const Text('Annulla'),
        ),
        FilledButton(
          onPressed: loading ? null : _create,
          child: Text(loading ? 'Creazione...' : 'Crea'),
        ),
      ],
    );
  }
}
