import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../database/app_database.dart';
import '../../../database/database_providers.dart';

class ScadenzePage extends ConsumerStatefulWidget {
  const ScadenzePage({super.key});

  @override
  ConsumerState<ScadenzePage> createState() => _ScadenzePageState();
}

class _ScadenzePageState extends ConsumerState<ScadenzePage> {
  int days = 7;

  @override
  Widget build(BuildContext context) {
    final data = ref.watch(scadenzeProvider(days));

    return Scaffold(
      appBar: AppBar(title: const Text('Scadenze')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 3, label: Text('3 giorni')),
                ButtonSegment(value: 7, label: Text('7 giorni')),
                ButtonSegment(value: 30, label: Text('30 giorni')),
              ],
              selected: {days},
              onSelectionChanged: (value) {
                setState(() => days = value.first);
              },
            ),
          ),
          Expanded(
            child: data.when(
              loading: () =>
                  const Center(child: CircularProgressIndicator()),
              error: (e, _) => Center(child: Text('Errore: $e')),
              data: (items) {
                if (items.isEmpty) {
                  return const Center(
                    child: Text('Nessuna scadenza nel periodo selezionato.'),
                  );
                }

                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  itemCount: items.length,
                  separatorBuilder: (_, __) =>
                      const SizedBox(height: 8),
                  itemBuilder: (context, index) =>
                      _ExpiryCard(item: items[index]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ExpiryCard extends StatelessWidget {
  const _ExpiryCard({required this.item});

  final LottoConProdotto item;

  @override
  Widget build(BuildContext context) {
    final expiry = item.lotto.dataScadenza!;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final date = DateTime(expiry.year, expiry.month, expiry.day);
    final days = date.difference(today).inDays;

    final expired = days < 0;
    final text = expired
        ? 'Scaduto da ${days.abs()} giorni'
        : days == 0
            ? 'Scade oggi'
            : 'Scade tra $days giorni';

    return Card(
      child: ListTile(
        leading: Icon(
          expired ? Icons.error_outline : Icons.schedule,
          color: expired
              ? Theme.of(context).colorScheme.error
              : Theme.of(context).colorScheme.primary,
        ),
        title: Text(item.prodotto.nome),
        subtitle: Text(
          'Lotto ${item.lotto.numeroLotto} • ${DateFormat('dd/MM/yyyy').format(expiry)}',
        ),
        trailing: Text(
          text,
          textAlign: TextAlign.right,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: expired
                ? Theme.of(context).colorScheme.error
                : null,
          ),
        ),
      ),
    );
  }
}
