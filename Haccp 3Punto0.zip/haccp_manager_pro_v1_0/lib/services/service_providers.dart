import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../database/database_providers.dart';
import 'report_service.dart';

final reportServiceProvider = Provider<ReportService>((ref) {
  return ReportService(ref.watch(databaseProvider));
});
