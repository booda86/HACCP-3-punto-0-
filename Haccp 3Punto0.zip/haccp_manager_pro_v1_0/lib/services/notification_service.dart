import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  NotificationService._();

  static final instance = NotificationService._();

  final plugin = FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();

    await plugin.initialize(
      const InitializationSettings(
        android: android,
        iOS: ios,
      ),
    );

    await plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();

    await plugin
        .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );
  }

  Future<void> showExpirySummary(int count) async {
    if (count <= 0) return;

    await plugin.show(
      1001,
      'Scadenze HACCP',
      '$count prodotti scaduti o in scadenza nei prossimi 7 giorni.',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'haccp_scadenze',
          'Scadenze HACCP',
          channelDescription: 'Avvisi per prodotti in scadenza',
          importance: Importance.high,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
    );
  }
}
