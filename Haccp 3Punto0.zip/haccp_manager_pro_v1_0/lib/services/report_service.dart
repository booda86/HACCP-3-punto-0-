import 'dart:io';

import 'package:excel/excel.dart' as xls;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../database/app_database.dart';

class ReportService {
  ReportService(this.database);

  final AppDatabase database;

  Future<File> generaReportTemperaturePdf({
    required DateTime from,
    required DateTime to,
  }) async {
    final data = await database.getTemperatureRange(from, to);
    final pdf = pw.Document();
    final df = DateFormat('dd/MM/yyyy HH:mm');

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (context) => [
          pw.Text(
            'HACCP Manager Pro',
            style: pw.TextStyle(
              fontSize: 20,
              fontWeight: pw.FontWeight.bold,
            ),
          ),
          pw.SizedBox(height: 6),
          pw.Text(
            'Registro temperature dal '
            '${DateFormat('dd/MM/yyyy').format(from)} al '
            '${DateFormat('dd/MM/yyyy').format(to)}',
          ),
          pw.SizedBox(height: 20),
          pw.TableHelper.fromTextArray(
            headers: const [
              'Data/Ora',
              'Frigorifero',
              '°C',
              'Esito',
              'Operatore',
            ],
            data: data.map((item) {
              return [
                df.format(item.temperatura.rilevataAt),
                item.frigo.nome,
                item.temperatura.valore.toStringAsFixed(1),
                item.temperatura.esito == 'ok' ? 'OK' : 'FUORI LIMITE',
                item.temperatura.operatore ?? '',
              ];
            }).toList(),
          ),
        ],
      ),
    );

    final dir = await getApplicationDocumentsDirectory();
    final file = File(
      '${dir.path}/report_temperature_${DateTime.now().millisecondsSinceEpoch}.pdf',
    );
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  Future<File> generaReportTemperatureExcel({
    required DateTime from,
    required DateTime to,
  }) async {
    final data = await database.getTemperatureRange(from, to);
    final excel = xls.Excel.createExcel();
    final sheet = excel['Temperature'];

    sheet.appendRow([
      xls.TextCellValue('Data/Ora'),
      xls.TextCellValue('Frigorifero'),
      xls.TextCellValue('Temperatura °C'),
      xls.TextCellValue('Esito'),
      xls.TextCellValue('Operatore'),
      xls.TextCellValue('Note'),
      xls.TextCellValue('Azione correttiva'),
    ]);

    final df = DateFormat('dd/MM/yyyy HH:mm');

    for (final item in data) {
      sheet.appendRow([
        xls.TextCellValue(df.format(item.temperatura.rilevataAt)),
        xls.TextCellValue(item.frigo.nome),
        xls.DoubleCellValue(item.temperatura.valore),
        xls.TextCellValue(
          item.temperatura.esito == 'ok' ? 'OK' : 'FUORI LIMITE',
        ),
        xls.TextCellValue(item.temperatura.operatore ?? ''),
        xls.TextCellValue(item.temperatura.note ?? ''),
        xls.TextCellValue(item.temperatura.azioneCorrettiva ?? ''),
      ]);
    }

    final bytes = excel.encode();
    if (bytes == null) {
      throw StateError('Impossibile generare il file Excel.');
    }

    final dir = await getApplicationDocumentsDirectory();
    final file = File(
      '${dir.path}/report_temperature_${DateTime.now().millisecondsSinceEpoch}.xlsx',
    );
    await file.writeAsBytes(bytes);
    return file;
  }
}
