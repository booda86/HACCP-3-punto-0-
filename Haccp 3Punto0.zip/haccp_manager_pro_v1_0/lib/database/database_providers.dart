import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app_database.dart';

final databaseProvider = Provider<AppDatabase>((ref) {
  final database = AppDatabase.defaults();

  database.seedFrigoriferi();

  ref.onDispose(() {
    database.close();
  });

  return database;
});

final magazzinoProvider = StreamProvider<List<LottoConProdotto>>((ref) {
  return ref.watch(databaseProvider).watchMagazzino();
});

final scadenzeProvider =
    StreamProvider.family<List<LottoConProdotto>, int>((ref, giorni) {
  return ref.watch(databaseProvider).watchScadenze(giorni: giorni);
});

final frigoriferiProvider = StreamProvider<List<Frigorifero>>((ref) {
  return ref.watch(databaseProvider).watchFrigoriferi();
});

final temperatureProvider =
    StreamProvider<List<TemperaturaConFrigo>>((ref) {
  return ref.watch(databaseProvider).watchTemperature();
});
