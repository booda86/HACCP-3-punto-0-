import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

part 'app_database.g.dart';

@DataClassName('Fornitore')
class Fornitori extends Table {
  @override
  String get tableName => 'fornitori';

  IntColumn get id => integer().autoIncrement()();
  TextColumn get nome => text()();
  TextColumn get partitaIva => text().nullable()();
  TextColumn get telefono => text().nullable()();
  TextColumn get email => text().nullable()();
  TextColumn get note => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

@DataClassName('Prodotto')
class Prodotti extends Table {
  @override
  String get tableName => 'prodotti';

  IntColumn get id => integer().autoIncrement()();
  TextColumn get nome => text()();
  TextColumn get categoria => text()();
  TextColumn get marca => text().nullable()();
  IntColumn get fornitoreId => integer().nullable().references(Fornitori, #id)();
  TextColumn get barcode => text().nullable()();
  TextColumn get allergeni => text().nullable()();
  TextColumn get note => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

@DataClassName('Lotto')
class Lotti extends Table {
  @override
  String get tableName => 'lotti';

  IntColumn get id => integer().autoIncrement()();
  IntColumn get prodottoId => integer().references(Prodotti, #id)();
  TextColumn get numeroLotto => text()();
  DateTimeColumn get dataArrivo => dateTime()();
  DateTimeColumn get dataScadenza => dateTime().nullable()();
  DateTimeColumn get dataApertura => dateTime().nullable()();
  RealColumn get quantita => real().nullable()();
  TextColumn get unitaMisura => text().withDefault(const Constant('kg'))();
  TextColumn get posizione => text().nullable()();
  TextColumn get stato => text().withDefault(const Constant('attivo'))();
  TextColumn get qrCode => text().nullable()();
  TextColumn get note => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

@DataClassName('Frigorifero')
class Frigoriferi extends Table {
  @override
  String get tableName => 'frigoriferi';

  IntColumn get id => integer().autoIncrement()();
  TextColumn get nome => text()();
  TextColumn get posizione => text().nullable()();
  RealColumn get temperaturaMin => real().nullable()();
  RealColumn get temperaturaMax => real().nullable()();
  BoolColumn get attivo => boolean().withDefault(const Constant(true))();
}

@DataClassName('Temperatura')
class Temperature extends Table {
  @override
  String get tableName => 'temperature';

  IntColumn get id => integer().autoIncrement()();
  IntColumn get frigoriferoId => integer().references(Frigoriferi, #id)();
  RealColumn get valore => real()();
  DateTimeColumn get rilevataAt => dateTime()();
  TextColumn get operatore => text().nullable()();
  TextColumn get esito => text().withDefault(const Constant('ok'))();
  TextColumn get azioneCorrettiva => text().nullable()();
  TextColumn get note => text().nullable()();
}

@DataClassName('UtenteLocale')
class Utenti extends Table {
  @override
  String get tableName => 'utenti';

  IntColumn get id => integer().autoIncrement()();
  TextColumn get firebaseUid => text().nullable().unique()();
  TextColumn get nome => text()();
  TextColumn get email => text().nullable()();
  TextColumn get ruolo => text().withDefault(const Constant('dipendente'))();
  BoolColumn get attivo => boolean().withDefault(const Constant(true))();
}

@DataClassName('ReportHaccp')
class ReportHaccpTable extends Table {
  @override
  String get tableName => 'report_haccp';

  IntColumn get id => integer().autoIncrement()();
  TextColumn get tipo => text()();
  DateTimeColumn get periodoDal => dateTime().nullable()();
  DateTimeColumn get periodoAl => dateTime().nullable()();
  TextColumn get filePath => text().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();
}

class LottoConProdotto {
  const LottoConProdotto({
    required this.prodotto,
    required this.lotto,
  });

  final Prodotto prodotto;
  final Lotto lotto;
}

class TemperaturaConFrigo {
  const TemperaturaConFrigo({
    required this.frigo,
    required this.temperatura,
  });

  final Frigorifero frigo;
  final Temperatura temperatura;
}

@DriftDatabase(
  tables: [
    Fornitori,
    Prodotti,
    Lotti,
    Frigoriferi,
    Temperature,
    Utenti,
    ReportHaccpTable,
  ],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase(super.e);

  AppDatabase.defaults() : super(driftDatabase(name: 'haccp_manager_pro'));

  @override
  int get schemaVersion => 2;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) => m.createAll(),
        onUpgrade: (m, from, to) async {
          if (from < 2) {
            await m.addColumn(prodotti, prodotti.barcode);
            await m.addColumn(lotti, lotti.dataApertura);
            await m.addColumn(lotti, lotti.qrCode);
            await m.addColumn(temperature, temperature.esito);
            await m.addColumn(temperature, temperature.azioneCorrettiva);
          }
        },
      );

  Stream<List<LottoConProdotto>> watchMagazzino() {
    final query = select(lotti).join([
      innerJoin(prodotti, prodotti.id.equalsExp(lotti.prodottoId)),
    ]);

    return query.watch().map((rows) {
      final items = rows.map((row) {
        return LottoConProdotto(
          prodotto: row.readTable(prodotti),
          lotto: row.readTable(lotti),
        );
      }).toList();

      items.sort((a, b) {
        final aDate = a.lotto.dataScadenza;
        final bDate = b.lotto.dataScadenza;
        if (aDate == null && bDate == null) return 0;
        if (aDate == null) return 1;
        if (bDate == null) return -1;
        return aDate.compareTo(bDate);
      });

      return items;
    });
  }

  Future<List<LottoConProdotto>> searchLotti(String queryText) async {
    final q = queryText.trim().toLowerCase();

    final query = select(lotti).join([
      innerJoin(prodotti, prodotti.id.equalsExp(lotti.prodottoId)),
    ]);

    final rows = await query.get();
    final all = rows.map((row) {
      return LottoConProdotto(
        prodotto: row.readTable(prodotti),
        lotto: row.readTable(lotti),
      );
    });

    if (q.isEmpty) return all.toList();

    return all.where((item) {
      return item.prodotto.nome.toLowerCase().contains(q) ||
          item.prodotto.categoria.toLowerCase().contains(q) ||
          item.lotto.numeroLotto.toLowerCase().contains(q) ||
          (item.prodotto.barcode?.toLowerCase().contains(q) ?? false) ||
          (item.lotto.qrCode?.toLowerCase().contains(q) ?? false);
    }).toList();
  }

  Stream<List<LottoConProdotto>> watchScadenze({int giorni = 7}) {
    return watchMagazzino().map((items) {
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final limit = today.add(Duration(days: giorni));

      return items.where((item) {
        final expiry = item.lotto.dataScadenza;
        if (expiry == null) return false;
        final date = DateTime(expiry.year, expiry.month, expiry.day);
        return !date.isAfter(limit);
      }).toList();
    });
  }

  Future<int> _findOrCreateFornitore(String nome) async {
    final cleaned = nome.trim();

    final existing = await (select(fornitori)
          ..where((f) => f.nome.lower().equals(cleaned.toLowerCase())))
        .getSingleOrNull();

    if (existing != null) return existing.id;

    return into(fornitori).insert(
      FornitoriCompanion.insert(nome: cleaned),
    );
  }

  Future<void> creaProdottoConLotto({
    required String nomeProdotto,
    required String categoria,
    String? marca,
    String? fornitore,
    String? barcode,
    String? allergeni,
    String? noteProdotto,
    required String numeroLotto,
    required DateTime dataArrivo,
    DateTime? dataScadenza,
    double? quantita,
    String unitaMisura = 'kg',
    String? posizione,
    String? qrCode,
    String? noteLotto,
  }) async {
    await transaction(() async {
      int? fornitoreId;

      if (fornitore != null && fornitore.trim().isNotEmpty) {
        fornitoreId = await _findOrCreateFornitore(fornitore);
      }

      final prodottoId = await into(prodotti).insert(
        ProdottiCompanion.insert(
          nome: nomeProdotto.trim(),
          categoria: categoria,
          marca: Value(_nullable(marca)),
          fornitoreId: Value(fornitoreId),
          barcode: Value(_nullable(barcode)),
          allergeni: Value(_nullable(allergeni)),
          note: Value(_nullable(noteProdotto)),
        ),
      );

      await into(lotti).insert(
        LottiCompanion.insert(
          prodottoId: prodottoId,
          numeroLotto: numeroLotto.trim(),
          dataArrivo: dataArrivo,
          dataScadenza: Value(dataScadenza),
          quantita: Value(quantita),
          unitaMisura: Value(unitaMisura),
          posizione: Value(_nullable(posizione)),
          qrCode: Value(_nullable(qrCode)),
          note: Value(_nullable(noteLotto)),
        ),
      );
    });
  }

  String? _nullable(String? value) {
    final clean = value?.trim();
    return clean == null || clean.isEmpty ? null : clean;
  }

  Future<void> eliminaLotto(int lottoId) async {
    await (delete(lotti)..where((l) => l.id.equals(lottoId))).go();
  }

  Future<void> segnaLottoAperto(int lottoId, DateTime date) async {
    await (update(lotti)..where((l) => l.id.equals(lottoId))).write(
      LottiCompanion(dataApertura: Value(date)),
    );
  }

  Future<void> seedFrigoriferi() async {
    final count = await frigoriferi.count().getSingle();
    if (count > 0) return;

    await batch((b) {
      b.insertAll(frigoriferi, [
        FrigoriferiCompanion.insert(
          nome: 'Frigo Pesce',
          posizione: const Value('Cucina'),
          temperaturaMin: const Value(0),
          temperaturaMax: const Value(4),
        ),
        FrigoriferiCompanion.insert(
          nome: 'Frigo Carne',
          posizione: const Value('Cucina'),
          temperaturaMin: const Value(0),
          temperaturaMax: const Value(4),
        ),
        FrigoriferiCompanion.insert(
          nome: 'Congelatore',
          posizione: const Value('Magazzino'),
          temperaturaMin: const Value(-24),
          temperaturaMax: const Value(-18),
        ),
      ]);
    });
  }

  Stream<List<Frigorifero>> watchFrigoriferi() {
    return (select(frigoriferi)..where((f) => f.attivo.equals(true))).watch();
  }

  Future<void> registraTemperatura({
    required int frigoriferoId,
    required double valore,
    required String operatore,
    String? note,
    String? azioneCorrettiva,
  }) async {
    final frigo = await (select(frigoriferi)
          ..where((f) => f.id.equals(frigoriferoId)))
        .getSingle();

    final outOfRange =
        (frigo.temperaturaMin != null && valore < frigo.temperaturaMin!) ||
            (frigo.temperaturaMax != null && valore > frigo.temperaturaMax!);

    await into(temperature).insert(
      TemperatureCompanion.insert(
        frigoriferoId: frigoriferoId,
        valore: valore,
        rilevataAt: DateTime.now(),
        operatore: Value(_nullable(operatore)),
        esito: Value(outOfRange ? 'fuori_limite' : 'ok'),
        azioneCorrettiva: Value(_nullable(azioneCorrettiva)),
        note: Value(_nullable(note)),
      ),
    );
  }

  Stream<List<TemperaturaConFrigo>> watchTemperature() {
    final query = select(temperature).join([
      innerJoin(
        frigoriferi,
        frigoriferi.id.equalsExp(temperature.frigoriferoId),
      ),
    ]);

    return query.watch().map((rows) {
      final result = rows.map((row) {
        return TemperaturaConFrigo(
          frigo: row.readTable(frigoriferi),
          temperatura: row.readTable(temperature),
        );
      }).toList();

      result.sort(
        (a, b) => b.temperatura.rilevataAt.compareTo(a.temperatura.rilevataAt),
      );
      return result;
    });
  }

  Future<List<TemperaturaConFrigo>> getTemperatureRange(
    DateTime from,
    DateTime to,
  ) async {
    final query = (select(temperature)
          ..where((t) => t.rilevataAt.isBetweenValues(from, to)))
        .join([
      innerJoin(
        frigoriferi,
        frigoriferi.id.equalsExp(temperature.frigoriferoId),
      ),
    ]);

    final rows = await query.get();
    return rows.map((row) {
      return TemperaturaConFrigo(
        frigo: row.readTable(frigoriferi),
        temperatura: row.readTable(temperature),
      );
    }).toList();
  }

  Future<int> countLottiInScadenza({int giorni = 7}) async {
    final items = await watchMagazzino().first;
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final limit = today.add(Duration(days: giorni));

    return items.where((item) {
      final expiry = item.lotto.dataScadenza;
      if (expiry == null) return false;
      final date = DateTime(expiry.year, expiry.month, expiry.day);
      return !date.isAfter(limit);
    }).length;
  }
}
