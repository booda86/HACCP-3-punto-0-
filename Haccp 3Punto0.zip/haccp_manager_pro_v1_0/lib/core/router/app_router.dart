import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/forgot_password_page.dart';
import '../../features/auth/presentation/login_page.dart';
import '../../features/auth/presentation/register_owner_page.dart';
import '../../features/dashboard/presentation/dashboard_page.dart';
import '../../features/lotti/presentation/ricerca_lotto_page.dart';
import '../../features/magazzino/presentation/add_inventory_page.dart';
import '../../features/magazzino/presentation/magazzino_page.dart';
import '../../features/personale/presentation/personale_page.dart';
import '../../features/report/presentation/report_page.dart';
import '../../features/scadenze/presentation/scadenze_page.dart';
import '../../features/scanner/presentation/scanner_page.dart';
import '../../features/temperature/presentation/temperature_page.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/login',
    redirect: (context, state) {
      final loggedIn = FirebaseAuth.instance.currentUser != null;
      final location = state.matchedLocation;

      final publicRoute = location == '/login' ||
          location == '/registrazione' ||
          location == '/password-dimenticata';

      if (!loggedIn && !publicRoute) return '/login';
      if (loggedIn && publicRoute) return '/dashboard';
      return null;
    },
    routes: [
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginPage(),
      ),
      GoRoute(
        path: '/registrazione',
        builder: (context, state) => const RegisterOwnerPage(),
      ),
      GoRoute(
        path: '/password-dimenticata',
        builder: (context, state) => const ForgotPasswordPage(),
      ),
      GoRoute(
        path: '/dashboard',
        builder: (context, state) => const DashboardPage(),
      ),
      GoRoute(
        path: '/magazzino',
        builder: (context, state) => const MagazzinoPage(),
      ),
      GoRoute(
        path: '/magazzino/nuovo',
        builder: (context, state) => const AddInventoryPage(),
      ),
      GoRoute(
        path: '/personale',
        builder: (context, state) => const PersonalePage(),
      ),
      GoRoute(
        path: '/ricerca-lotto',
        builder: (context, state) => const RicercaLottoPage(),
      ),
      GoRoute(
        path: '/scadenze',
        builder: (context, state) => const ScadenzePage(),
      ),
      GoRoute(
        path: '/temperature',
        builder: (context, state) => const TemperaturePage(),
      ),
      GoRoute(
        path: '/scanner',
        builder: (context, state) => const ScannerPage(),
      ),
      GoRoute(
        path: '/report',
        builder: (context, state) => const ReportPage(),
      ),
    ],
  );
});
