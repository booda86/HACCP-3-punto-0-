const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();

const db = getFirestore();
const auth = getAuth();

async function requireOwner(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Accesso richiesto.");
  }

  const profile = await db.collection("utenti").doc(request.auth.uid).get();

  if (!profile.exists) {
    throw new HttpsError("permission-denied", "Profilo utente non trovato.");
  }

  const data = profile.data();

  if (data.attivo !== true || data.ruolo !== "titolare") {
    throw new HttpsError(
      "permission-denied",
      "Solo il Titolare può eseguire questa operazione."
    );
  }

  return profile;
}

exports.createStaffUser = onCall(async (request) => {
  await requireOwner(request);

  const { nome, email, password, ruolo } = request.data || {};

  if (!nome || typeof nome !== "string" || nome.trim().length < 2) {
    throw new HttpsError("invalid-argument", "Nome non valido.");
  }

  if (!email || typeof email !== "string" || !email.includes("@")) {
    throw new HttpsError("invalid-argument", "Email non valida.");
  }

  if (!password || typeof password !== "string" || password.length < 8) {
    throw new HttpsError(
      "invalid-argument",
      "La password deve avere almeno 8 caratteri."
    );
  }

  if (!["chef", "dipendente"].includes(ruolo)) {
    throw new HttpsError(
      "invalid-argument",
      "Il ruolo deve essere Chef o Dipendente."
    );
  }

  let createdUser;

  try {
    createdUser = await auth.createUser({
      email: email.trim().toLowerCase(),
      password,
      displayName: nome.trim(),
      disabled: false,
    });

    await db.collection("utenti").doc(createdUser.uid).set({
      nome: nome.trim(),
      email: email.trim().toLowerCase(),
      ruolo,
      attivo: true,
      createdAt: FieldValue.serverTimestamp(),
      createdBy: request.auth.uid,
    });

    return { uid: createdUser.uid };
  } catch (error) {
    if (createdUser) {
      await auth.deleteUser(createdUser.uid).catch(() => null);
    }

    if (error.code === "auth/email-already-exists") {
      throw new HttpsError(
        "already-exists",
        "Esiste già un account con questa email."
      );
    }

    console.error(error);
    throw new HttpsError("internal", "Creazione utente non riuscita.");
  }
});

exports.setStaffRole = onCall(async (request) => {
  await requireOwner(request);

  const { uid, ruolo } = request.data || {};

  if (!uid || typeof uid !== "string") {
    throw new HttpsError("invalid-argument", "UID non valido.");
  }

  if (!["titolare", "chef", "dipendente"].includes(ruolo)) {
    throw new HttpsError("invalid-argument", "Ruolo non valido.");
  }

  if (uid === request.auth.uid) {
    throw new HttpsError(
      "failed-precondition",
      "Non puoi modificare il tuo stesso ruolo."
    );
  }

  const targetRef = db.collection("utenti").doc(uid);
  const target = await targetRef.get();

  if (!target.exists) {
    throw new HttpsError("not-found", "Utente non trovato.");
  }

  await targetRef.update({
    ruolo,
    updatedAt: FieldValue.serverTimestamp(),
    updatedBy: request.auth.uid,
  });

  return { ok: true };
});

exports.setStaffActive = onCall(async (request) => {
  await requireOwner(request);

  const { uid, attivo } = request.data || {};

  if (!uid || typeof uid !== "string" || typeof attivo !== "boolean") {
    throw new HttpsError("invalid-argument", "Dati non validi.");
  }

  if (uid === request.auth.uid) {
    throw new HttpsError(
      "failed-precondition",
      "Non puoi disattivare il tuo stesso account."
    );
  }

  const targetRef = db.collection("utenti").doc(uid);
  const target = await targetRef.get();

  if (!target.exists) {
    throw new HttpsError("not-found", "Utente non trovato.");
  }

  await Promise.all([
    targetRef.update({
      attivo,
      updatedAt: FieldValue.serverTimestamp(),
      updatedBy: request.auth.uid,
    }),
    auth.updateUser(uid, { disabled: !attivo }),
  ]);

  return { ok: true };
});
