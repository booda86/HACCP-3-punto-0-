# Roadmap

## v1.0
- autenticazione
- ruoli
- magazzino
- ricerca lotti
- scadenze
- temperature
- scanner
- PDF / Excel
- notifiche

## v1.1 consigliata
- aziende/ristoranti
- invito utenti
- sincronizzazione completa Firestore
- backup cloud
- allegati fotografici
- audit log
- filtri e statistiche
- sanificazioni
- ricevimento merci
- non conformità
- firme operatore
- etichette QR stampabili

## pubblicazione
- privacy policy
- cancellazione account
- App Store / Google Play
- Crashlytics
- analytics solo se necessari
- CI/CD GitHub Actions
